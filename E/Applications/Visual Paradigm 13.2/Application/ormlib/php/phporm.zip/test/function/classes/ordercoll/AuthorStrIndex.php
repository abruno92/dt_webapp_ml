<?php
class AuthorStrIndex{
 	
 	/**
 	 * @var string
 	 * @orm authorID char
 	 * @dbva id(assigned)
 	 */
 	private $authorID;
 	
 	/**
 	 * @orm has many BookStrIndex inverse(authorvar)
 	 * @dbva inverse(author) collection(authorIndex,char)
 	 */
 	private $books;
 	
 	/**
 	 * @var string
 	 * @orm authorName char
 	 */
 	private $authorName;
 	
 	public function &getAuthorID() {
 		return $this->authorID;
 	}
 	
 	public function setAuthorID(&$authorID) {
 		$this->authorID = $authorID;
 	}
 	
 	public function &getBooks() {
 		return $this->books;
 	}
 	
 	public function setBooks(&$books) {
 		$this->books = $books;
 	}
 	
 	public function &getAuthorName() {
 		return $this->authorName;
 	}
 	
 	public function setAuthorName(&$authorName) {
 		$this->authorName = $authorName;
 	}
 }
?>
