<?php
	class ComStudent{
 		/**
		 * @var String
		 * @orm id char
		 * @dbva id(assigned)
		*/
		private $studentID;
		
		/**
		 * @var int
		 * @orm id2 int
		 * @dbva id(assigned)
		*/
		private $studentID2;
		
		/**
		 * @var string
		 * @orm name char
		*/
		private $studentname;
	 	
	 	/**
	 	 * @orm composed_of many ComCourse
	 	 * @dbva jointable(com_course_student) fk(studentID,studentID2) inversefk(courseID,courseID2)
	 	 */
	 	 private $courses;
		
		public function &getStudentID() {
			return $this->studentID;
		}
		
		public function setStudentID(&$studentID) {
			$this->studentID = $studentID;
		}
		
		public function &getStudentID2() {
			return $this->studentID2;
		}
		
		public function setStudentID2(&$studentID2) {
			$this->studentID2 = $studentID2;
		}
		
		public function &getStudentname() {
			return $this->studentname;
		}
		
		public function setStudentname(&$studentname) {
			$this->studentname = $studentname;
		}
		
		public function &getCourses() {
			return $this->courses;
		}
		
		public function setCourses(&$courses) {
			$this->courses = $courses;
		}
 	}
?>
