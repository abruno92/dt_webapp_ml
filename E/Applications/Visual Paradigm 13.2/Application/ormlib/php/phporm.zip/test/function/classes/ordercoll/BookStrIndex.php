<?php
class BookStrIndex{
 		/**
 		 * @orm has one AuthorStrIndex inverse(books)
 		 * @dbva fk(author)
 		 */
 		private $authorvar;
 		
 		/**
 		 * @var string
 		 * @orm bookName char
 		 */
 		private $bookName;
 	
 		public function &getAuthorvar() {
 			return $this->authorvar;
 		}
 	
 		public function setAuthorvar(&$authorvar) {
 			$this->authorvar = $authorvar;
 		}
 	
 		public function &getBookName() {
 			return $this->bookName;
 		}
 	
 		public function setBookName(&$bookName) {
 			$this->bookName = $bookName;
 		}
 	}
?>
