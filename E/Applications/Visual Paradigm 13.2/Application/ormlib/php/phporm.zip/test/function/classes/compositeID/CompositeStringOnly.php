<?php
/*
 * Created on Aug 10, 2005 12:13:00 PM
 * author : Administrator
 */
 class CompositeStringOnly{
	/**
	 * @var string
	 * @orm id1 char
	 * @dbva id(assigned)
	 */
	private $id1;
	
	/**
	 * @var string
	 * @orm id2 char
	 * @dbva id(assigned)
	 */
	private $id2;
	
	/**
	 * @var string
	 * @orm char(20)
	 */
	private $name;

	public function &getId1() {
		return $this->id1;
	}

	public function setId1(&$id1) {
		$this->id1 = $id1;
	}

	public function &getId2() {
		return $this->id2;
	}

	public function setId2(&$id2) {
		$this->id2 = $id2;
	}

	public function &getName() {
		return $this->name;
	}

	public function setName(&$name) {
		$this->name = $name;
	}
	}
?>
