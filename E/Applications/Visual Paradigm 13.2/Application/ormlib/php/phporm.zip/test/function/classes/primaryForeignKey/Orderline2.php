<?php
/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Demo
 * License Type: Purchased
 */

/**
 * @orm Orderline2
 */
class Orderline2 {
  /**
   * @orm has one Order2 inverse(orderline2)
   * @dbva id(autogenerate) fk(Order2id) 
   */
  private $order2;
  
  /**
   * @orm has one Product2 inverse(orderline2)
   * @dbva id(autogenerate) fk(Product2id) 
   */
  private $product2;
  
  /**
   * @orm quantity int
   */
  private $quantity;
  
  /**
   * @orm unitPrice float
   */
  private $unitPrice;
  
  public function &getQuantity() {
    return $this->quantity;
  }
  
  
  public function setQuantity(&$quantity) {
    $this->quantity = $quantity;
  }
  
  
  public function &getUnitPrice() {
    return $this->unitPrice;
  }
  
  
  public function setUnitPrice(&$unitPrice) {
    $this->unitPrice = $unitPrice;
  }
  
  
  public function &getOrder2() {
    return $this->order2;
  }
  
  
  public function setOrder2(&$order2) {
    $this->order2 = $order2;
  }
  
  
  public function &getProduct2() {
    return $this->product2;
  }
  
  
  public function setProduct2(&$product2) {
    $this->product2 = $product2;
  }
  
  
  public function __toString() {
    $s = '';
    $s .= $this->order2 . ' ' . $this->product2;
    return $s;
  }
  
}

?>
