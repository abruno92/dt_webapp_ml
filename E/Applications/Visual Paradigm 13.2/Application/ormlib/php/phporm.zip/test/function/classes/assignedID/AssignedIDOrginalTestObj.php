<?php
/*
 * Created on Jul 30, 2005
 *
 */
 class AssignedIDOrginalTestObj {
	/**
	 * @var string
	 * @orm char(20)
	 */
	private $name;

	public function &getName() {
		return $this->name;
	}

	public function setName(&$name) {
		$this->name = $name;
	}
}
?>
