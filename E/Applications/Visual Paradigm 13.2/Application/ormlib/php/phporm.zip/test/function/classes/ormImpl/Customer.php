<?php
/**
 * @dbva implementation(CustomerImpl)
 */
abstract class Customer {
	/**
	* @var string
	* @orm id char
	* @dbva id(assigned)
	*/
	private $customerID;

	/**
	* @var string
	* @orm name char
	*/
	private $customerName;

	/**
	* @var string
	* @orm char
	*/
	private $account;

	/**
	* @var string
	* @orm char
	*/
	private $address;

 	public function &getCustomerID() {
 		return $this->customerID;
 	}

 	public function setCustomerID(&$customerID) {
 		$this->customerID = $customerID;
 	}

 	public function &getCustomerName() {
 		return $this->customerName;
 	}

 	public function setCustomerName(&$customerName) {
 		$this->customerName = $customerName;
 	}

 	public function &getAccount() {
 		return $this->account;
 	}

 	public function setAccount(&$account) {
 		$this->account = $account;
 	}

 	public function &getAddress() {
 		return $this->address;
 	}

 	public function setAddress(&$address) {
 		$this->address = $address;
 	}
	
	abstract function ccc();
}
?>


