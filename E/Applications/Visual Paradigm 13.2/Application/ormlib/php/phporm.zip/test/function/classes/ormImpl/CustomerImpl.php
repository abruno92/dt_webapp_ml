<?php
class CustomerImpl extends Customer {
	public function ccc() {
		return $this->getCustomerID() . "-" . $this->getCustomerName() . "-" . $this->getAccount() . "-" . $this->getAddress();
	}
}
?>

