<?php
/**
 * @dbva inherit(tablePerHierarchy) discriminator-value(2)
 */
class Professor extends PersonX{
	/**
	 * @var int
	 * @orm salary int 
	 */
	private $salary;

	public function &getSalary() {
		return $this->salary;
	}

	public function setSalary(&$salary) {
		$this->salary = $salary;
	}
}
?>
	