<?php
class ComAuthor{
 	/**
 	 * @var string
 	 * @orm authorID char
 	 * @dbva id(assigned)
 	 */
 	private $authorID;
 	
 	/**
 	 * @var int
 	 * @orm authorID2 int
 	 * @dbva id(assigned)
 	 */
 	private $authorID2;
 	
 	/**
 	 * @orm has many ComBook
 	 * @dbva inverse(author,author2)
 	 */
 	private $books;
 	
 	/**
 	 * @var string
 	 * @orm authorName char
 	 */
 	private $authorName;
 	
 	public function &getAuthorID() {
 		return $this->authorID;
 	}
 	
 	public function setAuthorID(&$authorID) {
 		$this->authorID = $authorID;
 	}
 	
 	public function &getAuthorID2() {
 		return $this->authorID2;
 	}
 	
 	public function setAuthorID2(&$authorID2) {
 		$this->authorID2 = $authorID2;
 	}
 	
 	public function &getBooks() {
 		return $this->books;
 	}
 	
 	public function setBooks(&$books) {
 		$this->books = $books;
 	}
 	
 	public function &getAuthorName() {
 		return $this->authorName;
 	}
 	
 	public function setAuthorName(&$authorName) {
 		$this->authorName = $authorName;
 	}
 }
?>
