<?php
/**
 * @dbva partialTable(extraInf,fk(id)) partialTable(extraInf2,fk(id))
 */
class User {
	/**
	 * @var int
	 * @orm int
	 * @dbva id(autogenerate)
	 */
	private $userID;
	
	/**
	 * @var string
	 * @orm char(60)
	 */
	private $username;
	
	/**
	 * @var string
	 * @orm char(60)
	 * @dbva partialTable(extraInf)
	 */
	private $address;
	
	/**
	 * @var string
	 * @orm char(60)
	 * @dbva partialTable(extraInf2)
	 */
	private $phone;
	
	public function &getUserID() {
		return $this->userID;
	}
	
	public function setUserID(&$userID) {
		$this->userID = $userID;
	}
	
	public function &getUsername() {
		return $this->username;
	}
	
	public function setUsername(&$username) {
		$this->username = $username;
	}
	
	public function &getAddress() {
		return $this->address;
	}
	
	public function setAddress(&$address) {
		$this->address = $address;
	}
	
	public function &getPhone() {
		return $this->phone;
	}
	
	public function setPhone(&$phone) {
		$this->phone = $phone;
	}
}
?>

