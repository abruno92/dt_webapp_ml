<?php
/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Demo
 * License Type: Purchased
 */

/**
 * @orm `Order`
 */
class Order {
  /**
   * @orm id int
   * @dbva id(assigned) 
   */
  private $id;
  
  /**
   * @orm has one Orderline inverse(order)
   * @dbva inverse(Orderid) 
   */
  private $orderline;
  
  public function &getId() {
    return $this->id;
  }
  
  
  public function setId(&$id) {
    $this->id = $id;
  }
  
  
  public function &getOrderline() {
    return $this->orderline;
  }
  
  
  public function setOrderline(&$orderline) {
    $this->orderline = $orderline;
  }
  
  
  public function __toString() {
    $s = '';
    $s .= $this->toString(false);
    return $s;
  }
  
  public function toString($idOnly) {
    $s = '';
    if($idOnly) {
      $s .= $this->id;
    }
    else {
      $s .= get_class($this);
      $s .= '[';
      $s .= 'id' . '=' . $this->id. ' ';
      if ($this->orderline instanceof epObjectWrapper)  {
        $s .= 'orderline.Persist_ID=' . $this->orderline->toString(true). ' ';
      }
      else {
        $s .= 'orderline=null ';
      }
      
      $s .= ']';
    }
    
    return $s;
  }
  
}

?>
