<?php
	class AddressBookEntry{
		
		/**
		 * @var string
		 * @orm id char(60)
		 * @dbva id(assigned)
		 */
		private $addID;
		
		
		/**
		 * @var string
		 * @orm name char
		 */
		private $aname;
		
		/**
		 * @var string
		 * @orm contactNo char
		 * @dbva array(keyColumn(id),index(phoneNumIndex,char))
		 */
		private $phoneNumber;

		public function &getAddID() {
			return $this->addID;
		}

		public function setAddID(&$addID) {
			$this->addID = $addID;
		}

		public function &getAname() {
			return $this->aname;
		}

		public function setAname(&$aname) {
			$this->aname = $aname;
		}

		public function &getPhoneNumber() {
			return $this->phoneNumber;
		}

		public function setPhoneNumber(&$phoneNumber) {
			$this->phoneNumber = $phoneNumber;
		}
	}
?>
