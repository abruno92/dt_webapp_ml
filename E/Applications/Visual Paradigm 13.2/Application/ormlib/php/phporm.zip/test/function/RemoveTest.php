<?php
	require_once( realpath(dirname(__FILE__)).'/../../ezpdo_runtime.php');
	$m = epManager::instance();
	$a = $m->create('AssignedIDStringTestObj');
	$a->name = "AssignedIDStringTestObj";
	$ax = $m->find($a);
	echo $ax[0]->name;
?>
